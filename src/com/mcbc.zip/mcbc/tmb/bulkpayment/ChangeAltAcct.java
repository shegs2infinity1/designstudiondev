package com.mcbc.tmb.bulkpayment;

/**
 * TODO: Document me!
 *
 * @author shegs
 *
 */
public class ChangeAltAcct {

}
