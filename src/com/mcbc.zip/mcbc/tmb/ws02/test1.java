package com.mcbc.tmb.ws02;

import java.util.ArrayList;
import java.util.List;

/**
 * TODO: Document me!
 *
 * @author debdas
 *
 */
public class test1 {

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub

        List<String> VersionList = new ArrayList<String>();
        List<String> ExcepVersion = new ArrayList<String>();
        List<String> ExcepCurrency = new ArrayList<String>();
        List<String> currentAcc = new ArrayList<String>();
        
        String ebws02reg = "ebws02reg"; // Original string
        String result = ebws02reg.substring(1); // Truncate the first character
        System.out.println("Result " + result);

        VersionList.add("FCY.OPRET.F03.TMB#LCY");
        VersionList.add("FCY.OPRET.F07.TMB#LCY");
        VersionList.add("FCY.ORDEP.F15.TMB#LCY");
        String result1;
        int ival = 1001;
                for (ival =1001;ival <1018 ; ival++) {
        result1 = String.valueOf(ival);
     
        currentAcc.add(result1);
                }        
        boolean ErrStatus = true;
        boolean RecExists = true;
        boolean ReversalReq = true;
        for (String Acc : VersionList) {
            String VExtract = Acc;
            System.out.println("Account Numbers " + VExtract);
            String[] newArr = VExtract.split("#");
            System.out.println("Successfully extracted");
            ExcepVersion.add(newArr[0]);
        
            ExcepCurrency.add(newArr[1]);
   
            
                System.out.println("Allowed Category  :" + currentAcc);

  String categ = "1012";
   if (currentAcc.contains(categ)) System.out.println("Catgeory exists ");       
            
            
           
        }
        int jj = VersionList.size();
        jj = 0;
        if (jj> 0 ){
        RecExists = true;
        }
        
        String VersionName = "FCY.OPRET.F03.TMB" ;
        if (ExcepVersion.contains(VersionName)) {
         System.out.println("contains works");   
        }
        int indexVersion = ExcepVersion.indexOf(VersionName);
        if (indexVersion == -1) {
          
                System.out.println("Version Does not exists");
           // retCurrency = "";
        } else {
            
                System.out.println("Version is at Index " + indexVersion);
         
                System.out.println("Version is at currency pos " + ExcepCurrency.get(indexVersion));
        
        }

        
        
        
        int caseStatus = 9 ;
        
        if (RecExists && ReversalReq)    caseStatus = 1  ;
        if (!RecExists && !ReversalReq)  caseStatus = 2;
        
        System.out.println("Final caseStatus " + caseStatus);
        switch (caseStatus) {
        case 1: ErrStatus = false;
        break;
        case 2: ErrStatus = false;
        break;
        default : ErrStatus = true;
        break;
        }
        System.out.println("Final Error Status " + ErrStatus);





    }

}
