package com.mcbc.tmb.ws02;

import java.util.ArrayList;
import java.util.List;

import com.temenos.api.TField;
import com.temenos.api.TStructure;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.hook.system.RecordLifecycle;
import com.temenos.t24.api.records.aclockedevents.AcLockedEventsRecord;
import com.temenos.t24.api.tables.ebws02paymentdetailstmb.EbWs02PaymentDetailsTmbRecord;
import com.temenos.t24.api.tables.ebwso2paramtmb.EbWso2ParamTmbRecord;
import com.temenos.t24.api.records.fundstransfer.FundsTransferRecord;
import com.temenos.t24.api.system.DataAccess;

/**
 * TODO: Document me!
 *
 * @author debdas * /** * @category EB.API -  V.BAUTH.SET.PARAM.TMB jar file -
 *         CSD_TmbWSO2Dev.jar
 * @param Application
 *            - EB.WSO2.PAYMENT.DETAILS.TMB
 * @param BEFORE
 *            AUTH ROUTINE - Read all details from EB.WS02.PAYMENT.DETAILS and
 *            populate the FT & AC.LOCKED.EVENTS variables
 * @param Version
 *            - VERSION.CONTROL WS02.PAYMENT.DETAILS.TMB
 * @return none
 *
 *
 */

public class tmbBAuthSetParam extends RecordLifecycle {
    boolean debugg = true;
    String ftId;
    String wsO2PaymentRec;
    FundsTransferRecord ftRec;
    AcLockedEventsRecord acLockRec;
    EbWs02PaymentDetailsTmbRecord ebwsO2PayRec;
    EbWso2ParamTmbRecord ebwsO2ParamRec;
    DataAccess da = new DataAccess(this);
    String ebwsO2InterfaceType;
    String ebwsO2FTTC;
    String ebwsO2Chargetype;
    String ebwsO2TransferType;
    String ebwsO2ParamId;
    String ebwsO2MsgId;
    String ebwsO2DebitAcc;
    String ebwsO2DebitCcy;
    String ebwsO2CreditAcc;
    String ebwsO2CreditCcy;
    String ebwsO2CDebitAmt;
    String ebwsO2Rate;
    String ebwsO2CCreditAmt;
    String ebwsO2PaymentDetails;
    String versionId;
    String ofsId = "BULK.OFS";
    String AppName = "";
    String NoofAuth;
    List<String> payDetSegment;
    String ReversalType = "INTREVERSE";
    String AuthType = "INTTRANAUTH";
    Boolean ReversalReq = false;
    Boolean ForcedAuth = false;
    String ProcessFunction = "INPUT";
    String ReverseFTId = "";
    String CreditRef = "";
    List<TField> PayDetails;

    @Override
    public void updateRecord(String application, String currentRecordId, TStructure currentRecord,
            TStructure unauthorisedRecord, TStructure liveRecord, TransactionContext transactionContext,
            List<com.temenos.t24.api.complex.eb.templatehook.TransactionData> transactionData,
            List<TStructure> currentRecords) {
        if (debugg)
            System.out.println("Entering Routine + tmbBAuthSetParam" + currentRecordId);
        try {
            ebwsO2PayRec = new EbWs02PaymentDetailsTmbRecord(currentRecord);
            ebwsO2MsgId = ebwsO2PayRec.getMsgId().toString();
            ebwsO2InterfaceType = ebwsO2PayRec.getInterfaceType().toString();
            ebwsO2TransferType = ebwsO2PayRec.getTransferType().toString();
            ebwsO2ParamId = ebwsO2InterfaceType + "-" + ebwsO2TransferType;

            ebwsO2DebitAcc = ebwsO2PayRec.getDebitAcct().toString();
            ebwsO2DebitCcy = ebwsO2PayRec.getDebitCcy().toString();
            ebwsO2CreditAcc = ebwsO2PayRec.getCreditAcct().toString();
            ebwsO2CreditCcy = ebwsO2PayRec.getCreditCcy().toString();
            ebwsO2CDebitAmt = ebwsO2PayRec.getDebitAmt().toString();
            ebwsO2Rate = ebwsO2PayRec.getExchangeRate().toString();
            ebwsO2FTTC = ebwsO2PayRec.getTransferType().toString();
            PayDetails = ebwsO2PayRec.getPaymentDetails();
            CreditRef = currentRecordId;
            System.out.println("EBWSO2PAYREC " + ebwsO2PayRec);
            if (ebwsO2TransferType.equals(AuthType))
                ForcedAuth = true;
            if (debugg)
                System.out.println("Forced Auth: " + ForcedAuth);
            if (ebwsO2CreditCcy.equals(ebwsO2DebitCcy) || ForcedAuth) {
                NoofAuth = "0";
            } else {
                NoofAuth = "1";
            }

            if (ebwsO2TransferType.equals(ReversalType))
                ReversalReq = true;
            if (ReversalReq) {

                NoofAuth = "0";
                ProcessFunction = "REVERSE";
                ReverseFTId = ebwsO2PayRec.getTranId().toString();
            }
            if (PayDetails.size() > 0) {
                getPaymentDetails();
            }

            versionId = ebwsO2PayRec.getVersionName().toString();
            ebwsO2InterfaceType = ebwsO2PayRec.getInterfaceType().toString();
            AppName = getAppDetails(ebwsO2ParamId);
            System.out.println("App Name" + AppName);

        } catch (Exception e) {
            System.out.println("Exception error EB WSO2 Payment Detail " + e);
        }

        try {
            // double crAmount = Double.parseDouble(ebwsO2CCreditAmt);
            // double drAmount = Double.parseDouble(ebwsO2CDebitAmt);

            if (AppName.equals("FUNDS.TRANSFER")) {

                if (!ReversalReq) {
                    setFtRec();
                    currentRecords.add(ftRec.toStructure());
                    if (debugg)
                        System.out.println("ft rec set" + ftRec.toString());
                } else {
                    try {
                        if (debugg)
                            System.out.println("Reversal -setting history record ");
                        ftRec = new FundsTransferRecord(da.getHistoryRecord("FUNDS.TRANSFER", ReverseFTId));
                        currentRecords.add(ftRec.toStructure());
                        if (debugg)
                            System.out.println("History Record Structure " + ftRec);
                    } catch (Exception et) {
                        System.out.println(" Not found in History " + ReverseFTId);
                    }

                }

            } else {
                System.out.println("Setting up data for AC Lock Version " + versionId);
                acLockRec = new AcLockedEventsRecord();
                acLockRec.setTransRef(currentRecordId);
                acLockRec.setAccountNumber(ebwsO2DebitAcc);
                acLockRec.setDescription(ebwsO2PaymentDetails);
                acLockRec.setLockedAmount(ebwsO2CDebitAmt);
                acLockRec.setTransRef(currentRecordId);
                System.out.println("Ac Locked Events:");
            }

            System.out.println("Calling txn  hook");
            com.temenos.t24.api.complex.eb.templatehook.TransactionData transactions = new com.temenos.t24.api.complex.eb.templatehook.TransactionData();
            System.out.println("Calling finished txn  hook");

            transactions.setFunction(ProcessFunction);
            if (ReversalReq) {
                transactions.setTransactionId(ReverseFTId);
                NoofAuth = "0";
            }
            transactions.setNumberOfAuthoriser(NoofAuth);
            transactions.setVersionId(versionId);
            transactionData.add(transactions);

            System.out.println("After update - " + transactionData.toString());

        } catch (Exception e) {
            System.out.println("Exception error Updating FT/AC Lock" + e);
        }

    }

    /**
     * 
     */
    private void getPaymentDetails() {
        // TODO Auto-generated method stub
        String fullPaymentDets = JoinPaydetails(PayDetails);
        int lenpay = fullPaymentDets.length();
        if (debugg)
            System.out.println("Length of paymentdetails after join" + lenpay);
        int maxlength = 140;
        fullPaymentDets = fullPaymentDets.substring(0, Math.min(lenpay, maxlength)).trim();
        if (debugg)
            System.out.println("After Joining " + fullPaymentDets);
        ebwsO2CCreditAmt = ebwsO2PayRec.getCreditAmt().toString();
        int nopay = ebwsO2PayRec.getPaymentDetails().size();
        payDetSegment = StringSplitter(fullPaymentDets, 35);
        if (debugg)
            System.out.println("After Splitting " + payDetSegment);

        if (nopay > 0) {
            ebwsO2PaymentDetails = ebwsO2PayRec.getPaymentDetails(0).toString();
        }

    }

    /**
     * 
     */
    private void setFtRec() {
        // TODO Auto-generated method stub
        ftRec = new FundsTransferRecord();
        ftRec.setDebitAcctNo(ebwsO2DebitAcc);
        ftRec.setCreditAcctNo(ebwsO2CreditAcc);
        ftRec.setDebitCurrency(ebwsO2DebitCcy);
        ftRec.setCreditCurrency(ebwsO2CreditCcy);
        ftRec.setDebitAmount(ebwsO2CDebitAmt);
        ftRec.setCreditTheirRef(CreditRef);
        ftRec.setTreasuryRate(ebwsO2Rate);
        String[] arrayPaydetconv = payDetSegment.toArray(new String[0]);
        int index = 0;
        for (String part : arrayPaydetconv) {
            if (debugg)
                System.out.println("Broken into 35 char each part" + part);
            ftRec.setPaymentDetails(part, index);
            index += 1;
        }

        if (debugg)
            System.out.println(ftRec.toString());

        if (debugg)
            System.out.println("ft rec set" + ftRec.toString());
    }

    /**
     * @param paymentDetails
     * @return
     */
    private String JoinPaydetails(List<TField> paymentDetails) {
        String Paydetails = "";
        try {
            StringBuilder sb = new StringBuilder();
            int nopay = paymentDetails.size();
            if (nopay > 0) {

                for (int i = 0; i < nopay; i += 1) { // Loop until the index
                                                     // reaches the array length
                    String paydetpart = paymentDetails.get(i).toString();

                    sb.append(paydetpart);
                }
            }

            Paydetails = sb.toString();
            if (debugg) {

                System.out.println("In joinig part " + Paydetails);
            }

        } catch (Exception esjoin) {
            System.out.println("Join Exception" + esjoin);
        }

        // TODO Auto-generated method stub
        return Paydetails;
    }

    /**
     * @param fullPaymentDets
     * @param i
     * @return
     */
    private List<String> StringSplitter(String input, int chunkSize) {
        List<String> result = new ArrayList<>();
        try {

            int length = input.length();

            for (int i = 0; i < length; i += chunkSize) {
                result.add(input.substring(i, Math.min(length, i + chunkSize)));
            }
            if (debugg) {

                System.out.println("In splitting part " + result);
            }
        } catch (Exception esplit) {
            System.out.println("Splitting Exception" + esplit);
        }

        return result;

    }

    String getAppDetails(String ParamId) {

        String AppName = "";
        try {
            EbWso2ParamTmbRecord ebwsO2ParamRec = new EbWso2ParamTmbRecord(
                    da.getRecord("EB.WSO2.PARAM.TMB", ebwsO2ParamId));
            AppName = ebwsO2ParamRec.getApplicationName().toString();
        } catch (Exception eparam) {
            System.out.println("Exception error EB WSO2 Payment Detail " + eparam);
            ebwsO2PayRec.getTransferType().setError("Invalid Transfer Type / Interface Type");
        }

        return AppName;
    }
}
